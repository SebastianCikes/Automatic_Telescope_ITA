bodies = [
    "Atria",
    "γ TrA",
    "β TrA"
]
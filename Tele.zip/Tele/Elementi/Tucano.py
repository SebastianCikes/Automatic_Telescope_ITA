bodies = [
    "α Tuc",
    "γ Tuc",
    "β1 Tuc",
    "ζ Tuc"
]
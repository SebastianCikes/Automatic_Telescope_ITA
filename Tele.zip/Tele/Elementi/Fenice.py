bodies = [
    "Ankaa",
    "ε Phe",
    "κ Phe",
    "Alrial V",
    "Alrial III",
    "Wurren",
    "δ Phe",
    "ψ Phe"
]
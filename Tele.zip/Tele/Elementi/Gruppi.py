bodies = [
    "Costellazioni",
    "Galassie",
    "Altro"
]
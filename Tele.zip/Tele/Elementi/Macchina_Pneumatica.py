bodies = [
    "α And",
    "η Ant"
]
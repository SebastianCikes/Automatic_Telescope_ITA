bodies = [
    "Alfirk",
    "Alderamin",
    "ζ Cep",
    "ι Cep",
    "Errai"
]
bodies = [
    "α Tel",
    "ζ Tel"
]
bodies = [
    "Bharani",
    "Hamal",
    "Sheratan",
    "Mesarthim"
]
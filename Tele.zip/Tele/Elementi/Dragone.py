bodies = [
    "Giausar",
    "κ Dra",
    "Thuban",
    "Edasich",
    "θ Dra",
    "Athebyne",
    "Aldhibah",
    "Alahakan",
    "Athafi II",
    "Altais",
    "Grumium",
    "Kuma",
    "Rastaban",
    "Eltanin"
]
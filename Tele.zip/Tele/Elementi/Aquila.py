bodies = [
    "Deneb al Okab Borealis",
    "Okab",
    "Almizan I",
    "Almizan II",
    "Almizan III",
    "Al Thalimain Prior",
    "Altair",
    "Alshain",
    "Tarazed"
]
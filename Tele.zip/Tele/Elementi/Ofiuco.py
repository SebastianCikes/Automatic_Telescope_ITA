bodies = [
    "c Oph",
    "Sabik",
    "Saik",
    "Yed Posterior",
    "κ Oph",
    "Rasalhague",
    "Ceblrai"
]
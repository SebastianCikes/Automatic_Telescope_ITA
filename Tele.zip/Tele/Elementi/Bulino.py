bodies = [
    "δ Cae",
    "α Cae",
    "β Cae"
]
bodies =  [
    "Algedi",
    "Dabih",
    "ψ Cap",
    "θ Cap",
    "ω Cap",
    "Yen",
    "ι Cap",
    "Nashira",
    "Deneb Algedi"
]
bodies = [
    "Vega",
    "Nasr Alwaki I",
    "δ2 Lyr",
    "Sulafat",
    "Sheliak"
]
bodies = [
    "α Mon",
    "ζ Mon",
    "δ Mon",
    "β Mon",
    "γ Mon",
    "ε Mon A",
    "HIP 29151 A"
]
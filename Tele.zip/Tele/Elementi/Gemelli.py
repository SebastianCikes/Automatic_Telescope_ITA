bodies = [
    "Alzirr",
    "λ Gem",
    "Alhena",
    "Mekbuda",
    "Wasat",
    "Polluce",
    "κ Gem",
    "υ Gem",
    "ι Gem",
    "Nucatai",
    "1 Gem",
    "Propus",
    "Tejat",
    "Mebsuta",
    "τ Gem",
    "Castore",
    "θ Gem"
]
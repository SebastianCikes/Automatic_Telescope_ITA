bodies = [
    "θ Lep",
    "η Lep",
    "ζ Lep",
    "Arneb",
    "Arsh al Jauzah",
    "Kursi al Jabbar",
    "Nihal",
    "ε Lep",
    "μ Lep",
    "λ Lep",
    "ν Lep",
    "κ Lep",
    "ι Lep"
]
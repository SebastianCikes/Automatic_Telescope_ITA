bodies = [
    "μ Ser",
    "Nasak Yamani II",
    "Unukalhai",
    "Nasak Yamani I",
    "Cho2",
    "Nasak Shamiya II",
    "Gudja"
]
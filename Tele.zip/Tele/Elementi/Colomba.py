bodies = [
    "ε Col",
    "Phact",
    "Wazn",
    "η Col",
    "γ Col",
    "Kurud II",
    "δ Col"
]
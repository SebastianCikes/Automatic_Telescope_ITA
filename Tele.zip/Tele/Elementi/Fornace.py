bodies = [
    "Dalim",
    "β For"
]
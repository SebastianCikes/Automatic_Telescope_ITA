bodies = [
    "Elnath",
    "τ Tau",
    "Ain",
    "Tianguan",
    "Aldebaran",
    "Chamukuy",
    "Prima Hyadum",
    "τ Tau",
    "ο Tau",
    "Secunda Hyadum",
    "Atlante",
    "δ3 Tau"
]
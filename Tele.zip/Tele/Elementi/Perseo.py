bodies = [
    "Atik",
    "Menkhib",
    "Menkib",
    "ε Per",
    "δ Per",
    "Mirfak",
    "γ Per",
    "Miram",
    "Algol",
    "Gorgonea Tertia",
    "16 Per"
]
bodies = [
    "Cor Caroli",
    "Chara"
]
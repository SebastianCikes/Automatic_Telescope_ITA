bodies = [
    "Sistema_solare",
    "Sistema_solare_minori"
]
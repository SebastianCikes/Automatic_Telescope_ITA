bodies = [
    "Miaplacidus",
    "ω Car",
    "θ Car",
    "w Car",
    "HIP 54463",
    "HIP 53253",
    "HIP 51232",
    "HIP 50371",
    "Aspidlske",
    "HIP 45080",
    "HIP 42568",
    "Avior",
    "Canopus"
]
bodies = [
    "β Cir",
    "α Cir",
    "γ Cir"
]
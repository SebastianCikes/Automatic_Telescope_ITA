bodies = [
    "α Mus",
    "β Mus",
    "λ Mus",
    "γ Mus"
]
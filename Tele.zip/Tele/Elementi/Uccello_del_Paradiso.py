bodies = [
    "α Aps",
    "γ Aps",
    "β Aps"
]
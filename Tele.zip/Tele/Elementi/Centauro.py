bodies = [
    "λ Cen",
    "HIP 56480",
    "δ Cen",
    "σ Cen",
    "Muhlifain",
    "Alnair",
    "ε Cen",
    "Hadar",
    "Rigil Kentaurus",
    "υ1 Cen",
    "μ Cen",
    "η Cen",
    "Ke Kwan",
    "ν Cen",
    "ι Cen",
    "Menkent"
]
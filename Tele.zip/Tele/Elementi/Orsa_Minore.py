bodies = [
    "Stella Polare",
    "Yildun",
    "Circitores",
    "Akfa Farkadain",
    "Kochab",
    "Pherkad",
    "Yed Post"
]
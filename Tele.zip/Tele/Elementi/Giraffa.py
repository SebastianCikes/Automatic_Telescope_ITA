bodies = [
    "HIP 25110",
    "γ Cam",
    "α Cam",
    "HIP 18505",
    "HIP 16228"
]
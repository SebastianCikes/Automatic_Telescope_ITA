bodies = [
    "β Pyx",
    "α Pyx",
    "γ Pyx"
]
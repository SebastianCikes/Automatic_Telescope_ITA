bodies = [
    "δ Vol",
    "ε Vol",
    "α Vol",
    "β Vol",
    "ζ Vol",
    "γ2 Vol"
]
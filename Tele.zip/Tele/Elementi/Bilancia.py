bodies = [
    "Braccio",
    "Zubenelgenubi",
    "Zubeneschmali",
    "Zubenelhakrabi",
    "θ Lib"
    ]
bodies = [
    "Aldulfin",
    "Rotanev",
    "Sualocin",
    "Al Salib",
    "Al Ukud"
]
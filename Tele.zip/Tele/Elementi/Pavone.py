bodies = [
    "Pavone",
    "γ Pav",
    "β Pav",
    "δ Pav",
    "ε Pav",
    "ζ Pav",
    "κ Pav",
    "λ Pav",
    "ξ Pav",
    "π Pav",
    "η Pav"
    ]
bodies = [
    "Alchiba",
    "Minkar",
    "Kraz",
    "Algorab",
    "Gienah",
    "η Crv"
]
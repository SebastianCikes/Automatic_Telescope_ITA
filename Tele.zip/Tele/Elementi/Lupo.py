bodies = [
    "χ Lup",
    "θ Lup",
    "η Lup",
    "η Lup",
    "ω Lup",
    "ζ Lup",
    "ρ Lup",
    "α Lup",
    "τ2 Lup",
    "KeKouan",
    "δ Lup",
    "φ1 Lup"
]
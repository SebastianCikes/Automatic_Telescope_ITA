bodies = [
    "δ Oct",
    "β Oct",
    "ν Oct"
]
bodies = [
    "η Nor",
    "κ Nor",
    "γ2 Nor",
    "ε Nor"
]
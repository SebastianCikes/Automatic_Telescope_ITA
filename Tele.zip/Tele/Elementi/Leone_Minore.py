bodies = [
    "10 LMi",
    "21 LMi",
    "β LMi",
    "Praecipua"
]
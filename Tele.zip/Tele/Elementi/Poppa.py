bodies = [
    "Naos",
    "Tureis",
    "Azmidi",
    "π Pup",
    "ν Pup",
    "τ Pup",
    "σ Pup"
]
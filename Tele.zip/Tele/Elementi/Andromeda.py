bodies = [
    "Almack",
    "Mirach",
    "μ And",
    "ν And",
    "δ And",
    "Alpheratz"
    ]
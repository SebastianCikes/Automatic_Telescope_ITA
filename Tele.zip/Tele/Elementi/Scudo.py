bodies = [
    "α Sct",
    "β Sct",
    "HIP 92814",
    "γ Sct"
]
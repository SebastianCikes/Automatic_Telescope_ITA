bodies = [
    "δ Dor",
    "HIP 27890",
    "β Dor",
    "α Dor",
    "γ Dor"
]
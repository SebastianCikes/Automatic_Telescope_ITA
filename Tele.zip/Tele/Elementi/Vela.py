bodies = [
    "Regol",
    "Suhail",
    "ψ Vel",
    "q Vel",
    "p Vel",
    "μ Vel",
    "φ Vel",
    "Alsephina",
    "ο Vel"
]
bodies = [
    "α Mic",
    "γ Mic",
    "ε Mic"
]
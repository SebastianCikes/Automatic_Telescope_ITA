bodies = [
    "Algenubi",
    "Rasalas",
    "Adhafera",
    "Algieba",
    "Al Jabhah",
    "Regolo",
    "Chertan",
    "Denebola",
    "Zosma"
]
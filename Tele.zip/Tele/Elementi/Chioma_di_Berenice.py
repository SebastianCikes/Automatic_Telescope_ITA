bodies = [
    "Diadem",
    "β Com",
    "Al Dafirah"
]
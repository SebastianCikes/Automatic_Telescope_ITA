bodies = [
    "α Hor",
    "ζ Hor",
    "μ Hor"
]
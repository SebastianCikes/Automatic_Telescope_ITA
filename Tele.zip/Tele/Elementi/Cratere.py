bodies = [
    "Alkes",
    "Al Sharasif",
    "γ Crt",
    "ζ Crt",
    "η Crt",
    "θ Crt",
    "ε Crt",
    "δ Crt"
]
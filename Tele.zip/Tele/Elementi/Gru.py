bodies = [
    "Aldhanab",
    "λ Gru",
    "Alnair",
    "δ1 Gru",
    "θ Gru",
    "ι Gru",
    "Tiaki",
    "ε Gru",
    "ζ Gru"
]
bodies = [
    "Rijl al Awwa",
    "Syrma",
    "Kang",
    "Spica",
    "Porrima",
    "Zaniah",
    "ν Vir",
    "Minelauva",
    "Vindemiatrix",
    "Heze",
    "τ Vir",
    "109 Vir"
]
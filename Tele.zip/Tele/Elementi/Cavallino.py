bodies = [
    "Kitalpha",
    "γ Equ",
    "δ Equ",
    "β Equ"
]
bodies = [
    "α Pic",
    "γ Pic",
    "β Pic"
]
bodies = [
    "α Lyn",
    "38 Lyn",
    "HIP 44700",
    "HIP 44248 A"
    "Alsciaukat",
    "21 Lyn",
    "15 Lyn",
    "2 Lyn"
]
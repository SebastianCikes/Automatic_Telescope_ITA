bodies = [
    "α Hyi",
    "δ Hyi",
    "ε Hyi",
    "γ Hyi",
    "β Hyi"
]
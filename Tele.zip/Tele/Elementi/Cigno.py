bodies = [
    "Fawaris I",
    "ι Cyg",
    "Fawaris II",
    "Sadr",
    "Aljanah",
    "Fawaris III",
    "μ1 Cyg",
    "η Cyg",
    "Albireo",
    "Deneb"
]
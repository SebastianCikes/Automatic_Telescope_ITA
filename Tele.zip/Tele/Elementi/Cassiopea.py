bodies = [
    "Segin",
    "Ruchban",
    "Navi",
    "Scedar",
    "Caph"
]
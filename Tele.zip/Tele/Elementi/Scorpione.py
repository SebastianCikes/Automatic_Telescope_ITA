bodies = [
    "Shaula",
    "Girtab",
    "Sargas",
    "η Sco",
    "ζ1 Sco",
    "Xamidimura",
    "Larawag",
    "Paikauhale",
    "Antares",
    "Acrab",
    "Dschubba",
    "Fang"
]
bodies = [
    "Mizan",
    "Mothallah",
    "γ Tri"
]
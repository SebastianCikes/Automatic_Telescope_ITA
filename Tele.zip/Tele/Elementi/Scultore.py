bodies = [
    "α Scl",
    "β Scl",
    "γ Scl"
]
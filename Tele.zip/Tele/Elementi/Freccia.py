bodies = [
    "Sham",
    "β Sge",
    "δ Sge",
    "γ Sge",
    "η Sge"
]
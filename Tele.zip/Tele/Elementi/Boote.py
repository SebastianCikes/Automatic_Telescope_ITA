bodies = [
    "υ Boo",
    "Muphrid",
    "Arturo",
    "ζ Boo",
    "Izar",
    "Thiba",
    "Nekkar",
    "Seginus",
    "ρ Boo"
]
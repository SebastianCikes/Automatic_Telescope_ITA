bodies = [
    "Gacrux",
    "Acrux",
    "Mimosa",
    "Imai"
]
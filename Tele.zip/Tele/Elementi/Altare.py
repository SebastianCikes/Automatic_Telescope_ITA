bodies = [
    "α Ara",
    "β Ara",
    "γ Ara",
    "δ Ara",
    "ζ Ara",
    "η Ara",
    "θ Ara"
    ]
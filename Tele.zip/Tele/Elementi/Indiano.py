bodies = [
    "Persiano",
    "θ Ind",
    "β Ind"
]
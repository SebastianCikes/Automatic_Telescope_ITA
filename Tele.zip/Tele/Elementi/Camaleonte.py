bodies = [
    "β Cha",
    "γ Cha",
    "α Cha"
]
bodies = [
    "Fomalhaut",
    "ε PsA",
    "η PsA",
    "θ PsA",
    "τ PsA",
    "Fum al Hui",
    "δ PsA"
]
bodies = [
    "α Ret",
    "β Ret",
    "δ Ret",
    "ε Ret"
]
bodies = [
    "HIP 92953",
    "ζ CrA",
    "δ CrA",
    "β CrA",
    "Meridiana",
    "γ CrA",
    "ε CrA",
    "HIP 92989",
    "λ CrA",
    "HIP 90887"
]
bodies = [
    "ι CrB",
    "ε CrB",
    "δ CrB",
    "γ CrB",
    "Alphecca",
    "Nusakan",
    "θ CrB"
]
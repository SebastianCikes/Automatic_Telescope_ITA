bodies = [
    "Furud",
    "Adhara",
    "κ CMa",
    "Nganurganity",
    "Wezen",
    "ω CMa",
    "Aludra",
    "Al Zara",
    "Sirio",
    "EZ CMa",
    "ν2 CMa",
    "ξ2 CMa",
    "Mirzam",
    "ι CMa",
    "Muliphein",
    "θ CMa"
]
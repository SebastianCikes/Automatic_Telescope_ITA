bodies = [
    "Albali",
    "Sadalsuud",
    "Sdalmelik",
    "Ancha",
    "ι Aqr",
    "σ Aqr",
    "τ Aqr",
    "Skat",
    "c2 Aqr",
    "Sadachbia",
    "Sadaltager",
    "η Aqr",
    "Hydor",
    "ψ1 Aqr",
    "b1 Aqr"
]
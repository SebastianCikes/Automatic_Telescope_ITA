bodies = [
    "Zubanah",
    "Asellus Borealis",
    "χ Cnc",
    "Asellus Australis",
    "Tarf",
    "Acubens"
]
bodies = [
    "Algenib",
    "Markab",
    "Suudalnujum",
    "Homam",
    "Biham",
    "Enif",
    "Guaina",
    "Matar",
    "π1 Peg",
    "Sadalbari",
    "Sadalnazi",
    "ι Peg",
    "κ Peg"
]